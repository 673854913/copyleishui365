//定时器
function startMove(){
	var oDiv=$(this)
	setInterval(,30);
}

//